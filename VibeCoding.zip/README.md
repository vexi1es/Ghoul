# S21 Launchpad

Локальная платформа стартаперов School 21: витрина стартапов, поиск команды, отзывы, инвестиции.

| Файл | Для кого |
|---|---|
| [docs/CONCEPT.md](docs/CONCEPT.md) | все — что строим и как питчим |
| [docs/API.md](docs/API.md) | **фронт** — контракт, сущности, что дергать на каждом экране |
| [openapi.yaml](openapi.yaml) | фронт — открыть в https://editor.swagger.io |
| [mock/db.json](mock/db.json) | фронт — данные до появления бэка; бэк — сид |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | **бэк** — Go-структура, модели, порядок реализации по минутам, демо-сценарий |

Бэк: Go + Gin + GORM + SQLite, порт `8080`. Фронт: любой стек, `BASE_URL = http://localhost:8080/api/v1`.
