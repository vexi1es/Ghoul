# S21 Launchpad — API контракт v1

**Base URL:** `http://localhost:8080/api/v1`
**Формат:** JSON, все поля `snake_case`, даты — ISO 8601 (`2026-09-13T10:00:00Z`).
**CORS:** открыт для всех origin.
**Swagger UI:** `http://localhost:8080/swagger/` (после запуска бэка). Файл контракта — [`openapi.yaml`](../openapi.yaml) — его можно открыть в https://editor.swagger.io и тыкать.

## Авторизация (упрощённая, без паролей)
`POST /auth/login` → возвращает `token`. Дальше во все защищённые запросы:
```
Authorization: Bearer <token>
```
| Код | Тело | Когда |
|---|---|---|
| 401 | `{"error":"unauthorized"}` | нет/битый токен |
| 403 | `{"error":"forbidden"}` | не фаундер / не инвестор / не адресат |
| 404 | `{"error":"not_found"}` | нет такой сущности |
| 400 | `{"error":"validation","details":{"title":"required"}}` | плохое тело |
| 409 | `{"error":"conflict"}` | логин занят, повторная заявка |

Для демо: на фронте одна кнопка «войти как…», токен в `localStorage`.

---

## Сущности

### User
```json
{
  "id": 1,
  "login": "kingsodi",
  "name": "Sodirxon",
  "role": "developer",
  "campus": "tashkent",
  "avatar_url": "https://api.dicebear.com/9.x/thumbs/svg?seed=kingsodi",
  "bio": "Бэкендер, люблю Go и распределёнку",
  "telegram": "@kingsodi",
  "created_at": "2026-09-01T10:00:00Z",
  "developer": {
    "skills": ["go", "postgres", "docker"],
    "experience": "2 года в бэкенде, проекты школы: webserv, ft_transcendence",
    "github": "https://github.com/kingsodi",
    "wave": "2024-09",
    "open_to_work": true
  },
  "investor": null
}
```
- `role`: `"developer"` | `"investor"`. `campus`: `"tashkent"` | `"samarkand"`.
- Заполнен ровно один из блоков `developer` / `investor`, второй — `null`.

Инвесторский блок:
```json
"investor": {
  "company": "Uzum Ventures",
  "ticket_min": 5000,
  "ticket_max": 50000,
  "currency": "USD",
  "interests": ["fintech", "edtech"],
  "portfolio": "12 сделок, 3 экзита"
}
```

### Startup
```json
{
  "id": 1,
  "title": "PeerReview",
  "tagline": "Код-ревью от пиров за 10 минут",
  "description": "Длинный текст (markdown ок)",
  "category": "devtools",
  "stage": "idea",
  "tags": ["go", "react", "ai"],
  "cover_url": "https://picsum.photos/seed/peerreview/800/400",
  "demo_url": null,
  "repo_url": "https://github.com/...",
  "founder": { "id": 1, "login": "kingsodi", "name": "Sodirxon", "avatar_url": "..." },
  "members": [
    { "user": { "id": 2, "login": "anna", "name": "Anna", "avatar_url": "..." }, "position": "Frontend" }
  ],
  "vacancies": [ "...Vacancy" ],
  "funding_goal": 20000,
  "funding_currency": "USD",
  "upvotes": 17,
  "upvoted_by_me": false,
  "feedback_count": 4,
  "members_count": 2,
  "open_vacancies_count": 1,
  "created_at": "2026-09-05T10:00:00Z"
}
```
- `stage`: `"idea"` | `"mvp"` | `"investment"`. `category` — id из `GET /categories`.
- `vacancies` — только открытые. `funding_goal` — `null`, если деньги не ищут.
- `upvoted_by_me` — всегда `false` без токена.
- В **списке** (`GET /startups`) поля `description`, `members`, `vacancies` **не возвращаются** — остальное одинаково.

### Vacancy
```json
{
  "id": 3,
  "startup_id": 1,
  "title": "Frontend разработчик",
  "description": "React + Tailwind, 5–10 часов в неделю",
  "skills": ["react", "typescript"],
  "status": "open",
  "match_score": 0.5,
  "applications_count": 2
}
```
- `status`: `"open"` | `"closed"`.
- `match_score` 0..1 — доля скиллов вакансии, которые есть у текущего юзера. `null` без токена или для инвестора. Фронт показывает как «Совпадение 50%».

### Application (заявка dev → вакансия)
```json
{
  "id": 7,
  "vacancy": { "id": 3, "title": "Frontend разработчик", "startup_id": 1, "startup_title": "PeerReview" },
  "user": { "id": 5, "login": "bek", "name": "Bekzod", "avatar_url": "...", "skills": ["react"] },
  "message": "Делал ft_transcendence на React, могу начать сегодня",
  "status": "pending",
  "created_at": "..."
}
```
`status`: `"pending"` | `"accepted"` | `"rejected"`.

### Invite (фаундер → dev)
```json
{
  "id": 2,
  "startup": { "id": 1, "title": "PeerReview", "cover_url": "..." },
  "from_user": { "id": 1, "login": "kingsodi", "name": "Sodirxon", "avatar_url": "..." },
  "to_user":   { "id": 5, "login": "bek", "name": "Bekzod", "avatar_url": "..." },
  "vacancy": { "id": 3, "title": "Frontend разработчик" },
  "message": "Видел твой профиль, залетай к нам",
  "status": "pending",
  "created_at": "..."
}
```
`vacancy` может быть `null`. `status`: `"pending"` | `"accepted"` | `"declined"`.

### Feedback (отзыв / идея)
```json
{
  "id": 11,
  "startup_id": 1,
  "user": { "id": 5, "login": "bek", "name": "Bekzod", "avatar_url": "...", "role": "developer" },
  "type": "review",
  "rating": 4,
  "text": "Классно, но нужен тёмный режим",
  "created_at": "..."
}
```
`type`: `"review"` (с `rating` 1..5) | `"idea"` (`rating: null`).

### Offer (инвест-предложение)
```json
{
  "id": 4,
  "startup": { "id": 1, "title": "PeerReview" },
  "investor": { "id": 9, "login": "aziz_vc", "name": "Aziz", "avatar_url": "...", "company": "Uzum Ventures" },
  "amount": 15000,
  "currency": "USD",
  "message": "Готов зайти seed-раундом за 10%",
  "status": "pending",
  "created_at": "..."
}
```
`status`: `"pending"` | `"accepted"` | `"declined"`.

---

## Эндпоинты

Легенда: 🔓 без токена · 🔒 нужен токен · 👑 только фаундер стартапа · 💰 только инвестор · 👨‍💻 только разработчик.

### Справочники
| | Метод | Путь | Ответ |
|---|---|---|---|
| 🔓 | GET | `/categories` | `[{"id":"fintech","name":"Финтех","emoji":"💳"}, ...]` |
| 🔓 | GET | `/stages` | `[{"id":"idea","name":"Идея","emoji":"💡"}, {"id":"mvp","name":"MVP","emoji":"🔨"}, {"id":"investment","name":"Инвестиции + Бета","emoji":"🚀"}]` |
| 🔓 | GET | `/skills` | `["go","python","react",...]` — для автокомплита тегов |

### Auth
| | Метод | Путь | Тело | Ответ |
|---|---|---|---|---|
| 🔓 | POST | `/auth/login` | `{"login":"kingsodi"}` | `{"token":"...","user":User}`; нет логина → 404 |
| 🔓 | POST | `/auth/register` | `{"login","name","role","campus","bio","telegram","developer":{...}}` или `"investor":{...}` | `201 {"token":"...","user":User}`; занят → 409 |
| 🔒 | GET | `/me` | | `User` |
| 🔒 | PATCH | `/me` | любые поля User кроме `id/login/role`, включая вложенный `developer`/`investor` | `User` |

### Стартапы
| | Метод | Путь | Параметры / тело | Ответ |
|---|---|---|---|---|
| 🔓 | GET | `/startups` | `q=` (по title/tagline/tags) · `category=` · `stage=` · `hiring=true` (есть открытые вакансии) · `funding=true` (funding_goal ≠ null) · `sort=new` \| `top` (default `new`) · `limit=20` · `offset=0` | `{"items":[Startup(list)],"total":42}` |
| 🔓 | GET | `/startups/{id}` | | `Startup` (полный) |
| 🔒👨‍💻 | POST | `/startups` | `{"title","tagline","description","category","stage","tags":[],"cover_url","demo_url","repo_url","funding_goal","funding_currency","vacancies":[{"title","description","skills":[]}]}` | `201 Startup` |
| 🔒👑 | PATCH | `/startups/{id}` | любые поля выше кроме `vacancies` — так меняют `stage` | `Startup` |
| 🔒👑 | DELETE | `/startups/{id}` | | `204` |
| 🔒 | POST | `/startups/{id}/upvote` | toggle | `{"upvotes":18,"upvoted_by_me":true}` |
| 🔓 | GET | `/startups/{id}/feedback` | `type=review` \| `idea` | `[Feedback]` |
| 🔒 | POST | `/startups/{id}/feedback` | `{"type","text","rating"}` | `201 Feedback` |

### Вакансии и заявки
| | Метод | Путь | Тело / параметры | Ответ |
|---|---|---|---|---|
| 🔓 | GET | `/vacancies` | `skills=go,react` · `q=` · `limit/offset`. С токеном dev — отсортировано по `match_score` desc | `{"items":[Vacancy + "startup":{"id","title","stage","cover_url"}],"total"}` |
| 🔒👑 | POST | `/startups/{id}/vacancies` | `{"title","description","skills":[]}` | `201 Vacancy` |
| 🔒👑 | PATCH | `/vacancies/{id}` | `{"title","description","skills","status"}` | `Vacancy` |
| 🔒👨‍💻 | POST | `/vacancies/{id}/apply` | `{"message"}` | `201 Application`; повторно → 409 |
| 🔒👑 | GET | `/startups/{id}/applications` | `status=` | `[Application]` |
| 🔒👑 | PATCH | `/applications/{id}` | `{"status":"accepted"}` \| `"rejected"` | `Application`. При `accepted` юзер добавляется в `members` с `position = vacancy.title` |

### Инвайты
| | Метод | Путь | Тело | Ответ |
|---|---|---|---|---|
| 🔒👑 | POST | `/startups/{id}/invites` | `{"user_id","vacancy_id","message"}` (`vacancy_id` опционален) | `201 Invite` |
| 🔒 | PATCH | `/invites/{id}` | `{"status":"accepted"}` \| `"declined"` — только адресат | `Invite`. При `accepted` юзер добавляется в `members` |

### Инвестиции
| | Метод | Путь | Тело | Ответ |
|---|---|---|---|---|
| 🔒💰 | POST | `/startups/{id}/offers` | `{"amount","currency","message"}`; стартап должен быть `stage=investment`, иначе 400 | `201 Offer` |
| 🔒👑 | GET | `/startups/{id}/offers` | | `[Offer]` |
| 🔒👑 | PATCH | `/offers/{id}` | `{"status":"accepted"}` \| `"declined"` | `Offer` |

### Люди
| | Метод | Путь | Параметры | Ответ |
|---|---|---|---|---|
| 🔓 | GET | `/users` | `role=developer` \| `investor` · `skills=go,react` (хотя бы один) · `campus=` · `q=` (login/name/bio) · `open_to_work=true` · `limit/offset` | `{"items":[User],"total"}` |
| 🔓 | GET | `/users/{id}` | | `User` + `"startups":[Startup(list)]` (где он фаундер или в members) |

### Кабинет — всё для страницы `/me` одним запросом
| | Метод | Путь |
|---|---|---|
| 🔒 | GET | `/me/dashboard` |

```json
{
  "my_startups": [ "...Startup(list) + \"pending_applications\": 2, \"pending_offers\": 1" ],
  "my_applications": [ "...Application — что я подавал (dev)" ],
  "my_invites": [ "...Invite — входящие мне (dev)" ],
  "my_offers": [ "...Offer — что я предлагал (investor)" ],
  "incoming_applications": [ "...Application — по всем моим стартапам (фаундер)" ],
  "incoming_offers": [ "...Offer — по всем моим стартапам (фаундер)" ]
}
```
Пустые массивы там, где роль не подходит.

---

## Что фронту нужно на каждом экране

| Экран | Запросы |
|---|---|
| `/` главная | `GET /categories`, `GET /stages`, `GET /startups?...` |
| `/startups/:id` | `GET /startups/{id}`, `GET /startups/{id}/feedback`; действия: `POST …/upvote`, `POST /vacancies/{id}/apply`, `POST …/feedback`, `POST …/offers` (только investor и stage=investment) |
| `/startups/new` | `GET /categories`, `GET /stages`, `GET /skills`, `POST /startups` |
| `/people` | `GET /users?...`, `GET /skills`; кнопка фаундера «Пригласить» → `POST /startups/{id}/invites` (список своих стартапов берётся из `/me/dashboard`) |
| `/users/:id` | `GET /users/{id}` |
| `/me` | `GET /me/dashboard`, `PATCH /me`, `PATCH /applications/{id}`, `PATCH /invites/{id}`, `PATCH /offers/{id}`, `PATCH /startups/{id}` (смена стадии) |
| `/login` | `POST /auth/login`, `POST /auth/register` |

## Демо-аккаунты (создаются сидом)
| login | role | зачем |
|---|---|---|
| `kingsodi` | developer | фаундер **PeerReview** (idea) — принимает заявку |
| `anna` | developer | фаундер **FoodMate** (mvp) |
| `timur` | developer | фаундер **QuizHub** (investment) — принимает предложение инвестора |
| `bek` | developer | свободный фронтендер — подаёт заявку |
| `aziz_vc` | investor | делает предложение QuizHub |

Полный набор — в [`mock/db.json`](../mock/db.json). Пока бэка нет, фронт может отдавать эти же данные из статики.
